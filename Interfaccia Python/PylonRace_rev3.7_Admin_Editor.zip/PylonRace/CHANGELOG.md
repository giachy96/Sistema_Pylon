# Versioni
Numerazione: 3.x per gli aggiornamenti normali, 4 per una versione major.

## rev3.7
- Modalità admin: passando sopra una cella compare cosa si può scrivere (formato dei tempi, tagli con -P1/-P2/-P3, totale, tagli, punti).

## rev3.6
- I risultati nella scheda Gara non sono più modificabili fuori dalla modalità admin (celle bloccate, suggerimento a video).

## rev3.5
- Modalità admin (pulsante "Admin" nella scheda Gara, con password): modifica libera di tempi, totale, tagli e punti,
  senza validazione né ricalcolo. Ogni modifica è scritta nel registro. Si esce con "Esci admin".
- Password impostata prima del build (imposta_password_admin.bat); nel programma c'è solo un hash salato.

## rev3.4
- Scheda Gara: **Sposta pilota** (scambio di due piloti della stessa categoria e manche, anche in round diversi) e
  **Sposta round** (un'intera tripletta prima/dopo un altro round, anche di un'altra categoria), con **Annulla modifica**.
  I numeri di round restano invariati. Bloccato tutto ciò che ha già risultati; non si inserisce prima del round in corso.
  Avviso se lo scambio crea un conflitto pilota-meccanico; se tocca il round in volo, i nomi vengono rinviati alla centrale.

## rev3.3
- Scheda Gara: il contatore dei round ("Avanzamento: 7 / 114 round") ora è visibile e chiaramente etichettato.

## rev3.2
- Impostazioni → Telegram → "Configura i messaggi…": testi di partenza, risultati e classifica modificabili,
  con segnaposto ({gara}, {manche}, {rosso}…), anteprima e ripristino dei predefiniti. Salvati per PC.

## rev3.1
- Scheda Gara: comandi INDIETRO / AVANTI / SHOW / START / STOP sempre visibili in alto, anche su schermi piccoli.
- Caselle dei piloti in volo più compatte (2 righe); pulsanti "Parti da qui" e "Reset" accorciati.

## rev3
- Sorteggio: tre modalità — controllo pilota-meccanico, casuale senza controllo, mantieni ordine elenco.
- Logo FT Models, tema scuro, dimensioni che seguono il testo (menu Vista), esportazione griglia in Excel,
  tripletta in volo rosso/verde/blu, modello di importazione piloti.

## rev1
- Prima versione: porting completo del sistema Excel/VBA.
