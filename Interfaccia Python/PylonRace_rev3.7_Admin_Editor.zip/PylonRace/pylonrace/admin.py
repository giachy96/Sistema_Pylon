"""Password della modalità admin.

La password si imposta PRIMA del build con tools/set_admin_password.py (o imposta_password_admin.bat):
nel programma finisce solo un hash salato (PBKDF2), mai la password in chiaro.
"""
from __future__ import annotations

import base64
import hashlib
import hmac
import json
import os
from pathlib import Path
from typing import Optional

ITERATIONS = 200_000


def admin_file() -> Path:
    return Path(__file__).resolve().parent / "data" / "admin.json"


def _hash(password: str, salt: bytes, iterations: int) -> bytes:
    return hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)


def set_password(password: str, path: Optional[Path] = None) -> Path:
    if len(password) < 4:
        raise ValueError("La password deve avere almeno 4 caratteri")
    path = Path(path) if path else admin_file()
    salt = os.urandom(16)
    data = {
        "iterations": ITERATIONS,
        "salt": base64.b64encode(salt).decode(),
        "hash": base64.b64encode(_hash(password, salt, ITERATIONS)).decode(),
    }
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data), encoding="utf-8")
    return path


def is_configured(path: Optional[Path] = None) -> bool:
    try:
        d = json.loads(Path(path or admin_file()).read_text(encoding="utf-8"))
        return bool(d.get("salt") and d.get("hash"))
    except (OSError, ValueError):
        return False


def verify(password: str, path: Optional[Path] = None) -> bool:
    try:
        d = json.loads(Path(path or admin_file()).read_text(encoding="utf-8"))
        salt = base64.b64decode(d["salt"])
        expected = base64.b64decode(d["hash"])
        got = _hash(password, salt, int(d.get("iterations", ITERATIONS)))
    except (OSError, ValueError, KeyError):
        return False
    return hmac.compare_digest(got, expected)
