"""Modelli per le tabelle (ordine di volo con risultati, piloti)."""
from __future__ import annotations

from typing import Optional

from PySide6.QtCore import QAbstractTableModel, QModelIndex, QSortFilterProxyModel, Qt
from PySide6.QtGui import QBrush, QColor, QFont, QPen
from PySide6.QtWidgets import QStyle, QStyledItemDelegate

from ..controller import RaceController
from ..models import COLOR_NAMES, N_LAPS, Pilot
from ..scoring import to_float
from . import theme

SCHED_HEAD = ["Gara", "Manche", "Round", "", "Pilota", "ID", "Meccanico"] + [f"L{i}" for i in range(1, N_LAPS + 1)] + [
    "Totale", "Tagli", "Punti"]
C_LAP0 = 7
C_TOTAL = C_LAP0 + N_LAPS
C_CUTS = C_TOTAL + 1
C_SCORE = C_TOTAL + 2


ADMIN_HELP = {
    "lap": ("MODALITÀ ADMIN — tempo del giro (doppio clic per scrivere)\n"
            "• Tempo normale: 5.031 oppure 5,031\n"
            "• Taglio: aggiungi il palo, es. 5.031-P1  (-P1, -P2 o -P3)\n"
            "• Due tagli nello stesso giro: 5.031-P1-P2\n"
            "• Vuoto o / = nessun tempo\n"
            "• Si può scrivere qualsiasi testo. Non cambia i tagli né i punti: li imposti tu nelle altre colonne."),
    "total": ("MODALITÀ ADMIN — tempo totale (doppio clic per scrivere)\n"
              "• Es. 61.320 oppure 61,320\n"
              "• Vuoto o / = nessun totale\n"
              "• Si può scrivere qualsiasi testo. Non ricalcola i punti: li imposti tu nella colonna Punti."),
    "cuts": ("MODALITÀ ADMIN — numero di tagli (doppio clic per scrivere)\n"
             "• Un numero intero: 0, 1, 2…\n"
             "• Vuoto = non indicato\n"
             "• È solo un'indicazione: i punti li scrivi tu nella colonna Punti."),
    "score": ("MODALITÀ ADMIN — punti validi per la classifica (doppio clic per scrivere)\n"
              "• Un numero, con punto o virgola: es. 61.32 oppure 61,32\n"
              "• Riferimenti: 0 tagli = totale · 1 taglio = totale × 1,1 · 2 tagli, timeout o doppio taglio = 200\n"
              "• Vuoto = nessun punteggio (il pilota non è conteggiato)\n"
              "• Deve essere un numero: il testo non è accettato."),
}


class ScheduleModel(QAbstractTableModel):
    """Ordine di volo (foglio GARA) con tempi e punteggi modificabili."""

    def __init__(self, ctl: RaceController, parent=None):
        super().__init__(parent)
        self.ctl = ctl
        self._n = len(ctl.race.slots)
        self.marked: set = set()   # righe scelte durante 'Sposta pilota/round'

    def refresh(self) -> None:
        n = len(self.ctl.race.slots)
        if n != self._n:
            self.beginResetModel()
            self._n = n
            self.endResetModel()
        elif n:
            self.dataChanged.emit(self.index(0, 0), self.index(n - 1, self.columnCount() - 1))

    # ---- struttura
    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else self._n

    def columnCount(self, parent=QModelIndex()):
        return len(SCHED_HEAD)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return SCHED_HEAD[section]
        return None

    def flags(self, index):
        f = super().flags(index)
        if index.column() >= C_LAP0 and self.ctl.admin_mode:      # i risultati si modificano solo in modalità admin
            f |= Qt.ItemIsEditable
        return f

    # ---- dati
    def _state(self, row: int) -> str:
        """current | refuel | '' """
        cur = self.ctl.race.current
        if cur < 0:
            return ""
        rnd = row // 3
        if rnd == cur:
            return "current"
        if rnd == cur + 1:
            return "refuel"
        return ""

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid() or index.row() >= len(self.ctl.race.slots):
            return None
        s = self.ctl.race.slots[index.row()]
        c = index.column()
        state = self._state(index.row())
        if role in (Qt.DisplayRole, Qt.EditRole):
            if c == 0:
                return s.category
            if c == 1:
                return s.manche
            if c == 2:
                return s.round
            if c == 3:
                return COLOR_NAMES[s.color][0]
            if c == 4:
                return s.full_name
            if c == 5:
                return s.pilot_id
            if c == 6:
                return s.mech
            if C_LAP0 <= c < C_TOTAL:
                v = s.laps[c - C_LAP0]
                return v if (v or role == Qt.EditRole) else ("/" if s.score is not None else "")
            if c == C_TOTAL:
                return s.total if (s.total or role == Qt.EditRole) else ("/" if s.score is not None else "")
            if c == C_CUTS:
                return "" if s.cuts is None else s.cuts
            if c == C_SCORE:
                return "" if s.score is None else (f"{s.score:g}" if role == Qt.DisplayRole else str(s.score))
        elif role == Qt.BackgroundRole:
            if index.row() in self.marked:
                return QBrush(QColor("#FFB74D"))
            if state == "current":
                return QBrush(QColor(theme.COLOR_FLIGHT[s.color]))
            if state == "refuel":
                return QBrush(QColor(theme.REFUEL_BG))
            if c == C_SCORE and s.cuts:
                return QBrush(QColor(theme.CUT1_BG if s.cuts == 1 else theme.CUT2_BG))
            if c == 3:
                return QBrush(QColor(theme.COLOR_STRONG[s.color]))
            if (index.row() // 3) % 2:
                return QBrush(QColor("#F7F8FA"))
            if s.needs_check and c in (C_TOTAL, C_SCORE):
                return QBrush(QColor("#FFD6D6"))
        elif role == Qt.ForegroundRole:
            if s.dummy:
                return QBrush(QColor(theme.MUTED))
        elif role == Qt.FontRole:
            f = QFont()
            if state == "current" or c == C_SCORE or index.row() in self.marked:
                f.setBold(True)
            if s.dummy:
                f.setItalic(True)
            return f
        elif role == Qt.TextAlignmentRole:
            if c in (4, 6):
                return int(Qt.AlignLeft | Qt.AlignVCenter)
            return int(Qt.AlignCenter)
        elif role == Qt.ToolTipRole:
            if c < C_LAP0:
                return None
            if not self.ctl.admin_mode:
                if s.needs_check:
                    return "Totale mancante: inserirlo o correggerlo in modalità admin"
                return "Risultati bloccati: per modificarli entra in modalità admin (pulsante Admin)"
            return ADMIN_HELP["lap" if c < C_TOTAL else {C_TOTAL: "total", C_CUTS: "cuts", C_SCORE: "score"}[c]]
        return None

    def setData(self, index, value, role=Qt.EditRole):
        if role != Qt.EditRole or not index.isValid() or not self.ctl.admin_mode:
            return False
        s = self.ctl.race.slots[index.row()]
        c = index.column()
        text = str(value).strip()
        if self.ctl.admin_mode:      # modalità admin: qualsiasi valore, nessun ricalcolo
            if C_LAP0 <= c < C_TOTAL:
                return self.ctl.admin_set(s, f"lap{c - C_LAP0}", text)
            return self.ctl.admin_set(s, {C_TOTAL: "total", C_CUTS: "cuts", C_SCORE: "score"}.get(c, ""), text)
        if C_LAP0 <= c < C_TOTAL:
            self.ctl.edit_lap(s, c - C_LAP0, text)
        elif c == C_TOTAL:
            self.ctl.edit_total(s, text)
        elif c == C_SCORE:
            if text in ("", "/"):
                self.ctl.edit_score(s, None)
            else:
                v = to_float(text)
                if v is None:
                    return False
                self.ctl.edit_score(s, v)
        else:
            return False
        return True


class ScheduleFilter(QSortFilterProxyModel):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.category: Optional[str] = None
        self.manche: Optional[int] = None

    def set_filter(self, category: Optional[str], manche: Optional[int]) -> None:
        self.category, self.manche = category, manche
        self.invalidateFilter()

    def filterAcceptsRow(self, row, parent):
        m = self.sourceModel()
        s = m.ctl.race.slots[row]
        if self.category and s.category != self.category:
            return False
        if self.manche and s.manche != self.manche:
            return False
        return True


PILOT_HEAD = ["N°", "Gara", "Nome", "Cognome", "Nome mecc.", "Cognome mecc.", "Naz.", "N° FAI", "Telefono", "ID"]


class PilotModel(QAbstractTableModel):
    def __init__(self, ctl: RaceController, parent=None):
        super().__init__(parent)
        self.ctl = ctl

    def refresh(self) -> None:
        self.beginResetModel()
        self.endResetModel()

    def pilot(self, row: int) -> Pilot:
        return self.ctl.race.pilots[row]

    def rowCount(self, parent=QModelIndex()):
        return 0 if parent.isValid() else len(self.ctl.race.pilots)

    def columnCount(self, parent=QModelIndex()):
        return len(PILOT_HEAD)

    def headerData(self, section, orientation, role=Qt.DisplayRole):
        if role == Qt.DisplayRole and orientation == Qt.Horizontal:
            return PILOT_HEAD[section]
        return None

    def data(self, index, role=Qt.DisplayRole):
        if not index.isValid():
            return None
        pilots = self.ctl.race.pilots
        p = pilots[index.row()]
        c = index.column()
        if role == Qt.DisplayRole:
            if c == 0:
                same = [q for q in pilots[: index.row() + 1] if q.category == p.category]
                return len(same)
            return [None, p.category, p.name, p.surname, p.mech_name, p.mech_surname, p.nation, p.fai, p.phone, p.id][c]
        if role == Qt.TextAlignmentRole and c in (0, 1, 6, 7, 9):
            return int(Qt.AlignCenter)
        return None


class KeepColorDelegate(QStyledItemDelegate):
    """La selezione non copre i colori delle righe: disegna solo un contorno scuro."""

    def paint(self, painter, option, index):
        from PySide6.QtWidgets import QStyleOptionViewItem

        opt = QStyleOptionViewItem(option)
        selected = bool(opt.state & QStyle.State_Selected)
        if selected:
            opt.state &= ~QStyle.State_Selected
        super().paint(painter, opt, index)
        if selected:
            painter.save()
            painter.setPen(QPen(QColor("#1F3A8A"), 2))
            painter.drawRect(opt.rect.adjusted(1, 1, -1, -1))
            painter.restore()
