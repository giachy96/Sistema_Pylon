@echo off
REM Imposta la password della modalita' admin. Eseguire PRIMA di build_exe.bat.
cd /d "%~dp0"
if exist .venv\Scripts\python.exe (set PY=.venv\Scripts\python.exe) else (set PY=python)
%PY% tools\set_admin_password.py
pause
