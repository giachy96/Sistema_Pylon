"""Imposta la password della modalità admin (da eseguire prima del build). Salva solo un hash."""
import getpass
import importlib.util
import sys
from pathlib import Path

spec = importlib.util.spec_from_file_location("admin", Path(__file__).resolve().parents[1] / "pylonrace" / "admin.py")
admin = importlib.util.module_from_spec(spec)
spec.loader.exec_module(admin)


def main() -> int:
    print("Password della modalità admin di Pylon Race")
    if admin.is_configured():
        print("(ne esiste già una: verrà sostituita)")
    pw = getpass.getpass("Nuova password: ")
    if pw != getpass.getpass("Ripeti la password: "):
        print("Le due password non coincidono.")
        return 1
    try:
        path = admin.set_password(pw)
    except ValueError as exc:
        print(exc)
        return 1
    print(f"Fatto. Salvato l'hash in {path}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
