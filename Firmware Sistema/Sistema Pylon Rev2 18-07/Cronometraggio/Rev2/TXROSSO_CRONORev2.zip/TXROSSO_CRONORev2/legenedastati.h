Githb percorso di lavoro Giacomo v2
  CODICE STRUTTURA : XYZ
 // X --> STATO y --> CHI Z ---> COSA
 
 /*
STATO :

1XX --> STARTUP
2XX-->SHOW
3XX-->START GARA
4XX -->INVIO TEMPI/TAGLI
5XX --> FINE GARA



Colori  Y :
	 0 Stato Generico
	 1 Verde
         2 Rosso
         3 Blu


  COSA Z : 0 Stato Generico
	   1 --> TAGLIO
           2--> SEMAFORO
		   3--> TEMPI
		   
*/