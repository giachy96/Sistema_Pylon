# Please browse the docs from either http://nrf24.github.io/RF24 or https://rf24.rtfd.io
## Intended for use in Doxygen

These markdown files (\*.md) in this docs folder contain relative hyperlinks. Any relative hyperlinks will not work when viewing these markdown files in github.
