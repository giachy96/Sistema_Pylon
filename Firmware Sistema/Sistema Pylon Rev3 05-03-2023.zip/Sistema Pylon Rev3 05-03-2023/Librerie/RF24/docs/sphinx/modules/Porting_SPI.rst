Porting: SPI
============

.. doxygengroup:: Porting_SPI
    :members:
    :undoc-members:
    :protected-members:
    :private-members:
    :content-only:

spi.h
-----------

.. literalinclude:: ../../../utility/Template/spi.h
    :caption: utility/Template/spi.h
