/* 
 
Stato "Sicn" = 101;
Stato "SendFirst"= 200;
Stato "Send" = 201;
Stato "Fine Manche" =300;
Stato "Stop"=500;



Colori : 01 Verde
         02 Rosso
         03 Blu


         */
         
