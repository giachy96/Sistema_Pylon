float lontoflt ( unsigned long loong ){
   float flt;
   flt = loong; 
   flt = flt/1000;
  return flt;
  }


 
String tempistring( unsigned long ray[]  ) {
  int dim  = sizeof(ray);
  char buff[10];
  String valueString = "";
  for (int i = 0 ; i =dim; i++) {
    dtostrf(lontoflt(ray[i]), 4, 3, buff);  //4 is mininum width, 6 is precision
    valueString += buff;
    valueString += ", ";
  }
  return valueString;
}


// sscanf Read formatted data from string (function ) ci potrebbe servire per leggere una riga formattata
  

unsigned long Catturatempo (unsigned long ray[] ,  int indice , unsigned long tempobase){
    unsigned long tempo_appoggio = 0;
    unsigned long tempo_cronometrato;  

    
    tempo_cronometrato = millis() - tempobase;
    ray[indice]= tempo_cronometrato;
     if (indice == 0){
       ray[indice]= tempo_cronometrato;
       }
      else if ( indice > 0) {
          for(int i = 0; i <=indice  ; i++){
             tempo_appoggio = tempo_appoggio + ray[i-1];
             
               }
          ray[indice]= ray[indice] - tempo_appoggio;
                }
    
    return ray;

  }
  
unsigned long  CalcoloTempo (unsigned long ray[]){
  
  unsigned long tempotot;
  int i;
  for(i=0; i=9; i=i+1) {
     tempotot=tempotot+ray[i];
      return tempotot;
   }
  
  }
