extern int lapcounter ;
extern int pinbatt ;
extern unsigned long parziale;
float tensione_float = 0;
char vout[8]; // Buffer big enough for 7-character float

void draw(int cases , U8GLIB_SH1106_128X64 u8g) {
 switch(cases){
 
  case 0:
  // Standby
       tensione_float = analogRead(pinbatt);  
  tensione_float = (tensione_float/1023)*5; 
  dtostrf(tensione_float, 6, 2, vout); // Leave room for too large numbers!
  
  //tensione_batt = char(tensione_float );// using a float and the decimal places
  u8g.setFont(u8g_font_9x15);
  u8g.setFontRefHeightExtendedText();
  u8g.setDefaultForegroundColor();
  u8g.setFontPosTop();
   u8g.drawFrame(0,0,125,64);
  u8g.drawStr(0, 8 ," Voltaggio");
  u8g.drawStr(0, 20 ," Batteria");
  u8g.drawStr(60, 40 ," V");
  u8g.drawStr(10, 40, vout );
  //Serial.println(vout); 
  
  break;
   case 1:
  // Sinc
    
  u8g.setFont(u8g_font_9x15);
  u8g.setFontRefHeightExtendedText();
  u8g.setDefaultForegroundColor();
  u8g.setFontPosTop();
  u8g.drawStr(0, 5 ," Sincronizzato");
  u8g.drawStr(0, 25 ," Pronto per");
  u8g.drawStr(0, 40 ," la gara");  
  break;
  case 2:
  // Tempo
  
      
  u8g.setFont(u8g_font_9x15);
  u8g.setFontRefHeightExtendedText();
  u8g.setDefaultForegroundColor();
  u8g.setFontPosTop();
  u8g.drawStr(5, 5 ,"LAP N:");
  char buf[9];
  sprintf (buf, "%d", lapcounter);
  u8g.drawStr(65, 5 ,buf);
  u8g.drawStr(0, 25 ," Tempo ");
  u8g.drawStr(0, 40 ," parziale");  
  break;

     case 3:
  // STOP
      
  u8g.setFont(u8g_font_9x15);
  u8g.setFontRefHeightExtendedText();
  u8g.setDefaultForegroundColor();
  u8g.setFontPosTop();
  u8g.drawStr(0, 5 ," STOP Gara!");
  u8g.drawStr(0, 25 ," Invio dei ");
  u8g.drawStr(0, 40 ," dati ");  
  break;
  
  default:
    // statements
    break;
 }
}
