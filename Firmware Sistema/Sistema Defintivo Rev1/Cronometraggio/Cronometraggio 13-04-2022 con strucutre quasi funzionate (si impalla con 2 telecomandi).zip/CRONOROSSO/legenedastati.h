Stato "Sicn" = 101;
Stato "SendFirst"= 200;
Stato "Send" = 201;
Stato "Fine Manche" =300;
Stato "Stop"=500;
