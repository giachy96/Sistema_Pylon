float lontoflt ( unsigned long loong ) {
  float flt;
  flt = (float)loong;
  flt = flt / 1000;
  return flt;
}

// sscanf Read formatted data from string (function ) ci potrebbe servire per leggere una riga formattata

void Catturatempo ( float* tempo_flt, long* tempo_parziale, int indice , unsigned long tempobase) {
  unsigned long tempo_appoggio = 0;
  unsigned long tempo_cronometrato;

  if (indice < 0) {
    memset(*(tempo_parziale), 0, sizeof(*(tempo_parziale)));
    tempo_appoggio = 0;
  }
  else if (indice == 0) {
    tempo_cronometrato = millis() - tempobase;
    *(tempo_parziale + indice) =  tempo_cronometrato;
     *(tempo_flt + indice) = lontoflt(tempo_parziale[indice] );
  
    
  }
  else if ( indice > 0) {
    tempo_cronometrato = millis() - tempobase;
    *(tempo_parziale + indice) =  tempo_cronometrato;
    for (int i = 1; i <= indice  ; i++) {

      tempo_appoggio = tempo_appoggio + *(tempo_parziale + i - 1); // NON ENTRA DENTRO IL FOR
    }
    *(tempo_parziale + indice) = *(tempo_parziale + indice) - tempo_appoggio;
    *(tempo_flt + indice) = lontoflt( tempo_parziale[indice]);
  }
  //return *tempo_flt;

}

float  CalcoloTempo (float poitemp[]) {
  float tempotot = 0;
  for (int k = 0; k <= 10; k ++) {
    tempotot = tempotot + poitemp[k];
  }
  // Serial.println(tempotot);
  return tempotot;
}
